package com.globalbank.ui.admin

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.globalbank.GlobalBankApplication
import com.globalbank.R
import com.globalbank.adapters.CustomerAdapter
import com.globalbank.adapters.TransactionAdapter
import com.globalbank.managers.DatabaseManager
import com.globalbank.managers.MiningManager
import com.globalbank.managers.SettingsManager
import com.globalbank.models.User
import kotlinx.coroutines.*

class AdminDashboardActivity : AppCompatActivity() {
    
    private lateinit var totalCustomersText: TextView
    private lateinit var totalBalanceText: TextView
    private lateinit var totalCryptoText: TextView
    private lateinit var transactionsTodayText: TextView
    private lateinit var miningToggle: Switch
    private lateinit var miningStatusText: TextView
    private lateinit var liveActivityRecyclerView: RecyclerView
    
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)
        
        initializeViews()
        setupListeners()
        refreshDashboard()
        startLiveUpdates()
    }
    
    private fun initializeViews() {
        totalCustomersText = findViewById(R.id.totalCustomersText)
        totalBalanceText = findViewById(R.id.totalBalanceText)
        totalCryptoText = findViewById(R.id.totalCryptoText)
        transactionsTodayText = findViewById(R.id.transactionsTodayText)
        miningToggle = findViewById(R.id.miningToggle)
        miningStatusText = findViewById(R.id.miningStatusText)
        liveActivityRecyclerView = findViewById(R.id.liveActivityRecyclerView)
        
        liveActivityRecyclerView.layoutManager = LinearLayoutManager(this)
    }
    
    private fun setupListeners() {
        miningToggle.setOnCheckedChangeListener { _, isChecked ->
            SettingsManager.setMiningEnabled(isChecked)
            miningStatusText.text = if (isChecked) &quot;Mining: ON&quot; else &quot;Mining: OFF&quot;
            
            if (isChecked) {
                MiningManager.startMining()
                Toast.makeText(this, &quot;Mining started&quot;, Toast.LENGTH_SHORT).show()
            } else {
                MiningManager.stopMining()
                Toast.makeText(this, &quot;Mining stopped&quot;, Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun refreshDashboard() {
        scope.launch {
            withContext(Dispatchers.IO) {
                val users = DatabaseManager.getAllUsers()
                val transactions = DatabaseManager.getAllTransactions()
                
                val totalBalance = users.sumOf { it.balance }
                val totalCrypto = users.sumOf { it.cryptoBalance }
                val today = java.util.Date()
                val transactionsToday = transactions.count {
                    it.date.toDateString() == today.toDateString()
                }
                
                withContext(Dispatchers.Main) {
                    totalCustomersText.text = users.size.toString()
                    totalBalanceText.text = &quot;$${String.format(&quot;%.2f&quot;, totalBalance)}&quot;
                    totalCryptoText.text = String.format(&quot;%.8f&quot;, totalCrypto) + &quot; BTC&quot;
                    transactionsTodayText.text = transactionsToday.toString()
                    
                    miningToggle.isChecked = SettingsManager.isMiningEnabled()
                    miningStatusText.text = if (SettingsManager.isMiningEnabled()) {
                        &quot;Mining: ON&quot;
                    } else {
                        &quot;Mining: OFF&quot;
                    }
                    
                    updateLiveActivity(transactions)
                }
            }
        }
    }
    
    private fun updateLiveActivity(transactions: List&lt;com.globalbank.models.Transaction&gt;) {
        val recentTransactions = transactions.take(10)
        val adapter = TransactionAdapter(recentTransactions, true)
        liveActivityRecyclerView.adapter = adapter
    }
    
    private fun startLiveUpdates() {
        scope.launch {
            while (isActive) {
                delay(5000) // Update every 5 seconds
                refreshDashboard()
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
    
    private fun java.util.Date.toDateString(): String {
        val format = java.text.SimpleDateFormat(&quot;yyyy-MM-dd&quot;, java.util.Locale.getDefault())
        return format.format(this)
    }
}